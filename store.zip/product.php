<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";

$username = $_SESSION["username"];

/* =======================
   PAGINATION
   ======================= */
$limit = 10;
$page = isset($_GET["page"]) ? (int)$_GET["page"] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

/* TOTAL PRODUCTS */
$totalProducts = 0;
$totalRes = mysqli_query($link, "SELECT COUNT(*) AS total FROM products");
if ($totalRes) {
    $row = mysqli_fetch_assoc($totalRes);
    $totalProducts = $row["total"];
}
$totalPages = ceil($totalProducts / $limit);

/* PRODUCTS LIST */
$products = mysqli_query(
    $link,
    "SELECT * FROM products ORDER BY id DESC LIMIT $limit OFFSET $offset"
);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Products</title>

    <link rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body class="bg-light">

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <span class="navbar-brand">
            Welcome, <?php echo htmlspecialchars($username); ?>
        </span>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="product.php">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="order.php">Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">

        <h3>Products</h3>

        <!-- ADD PRODUCT -->
        <form method="post" action="product_action.php" class="form-inline mb-3">
            <input type="hidden" name="action" value="add_product">

            <input type="text"
                name="product_name"
                class="form-control mr-2"
                placeholder="Product name"
                required>

            <input type="number"
                step="0.01"
                name="price"
                class="form-control mr-2"
                placeholder="Price"
                required>

            <button type="submit" class="btn btn-success">Add</button>
        </form>

        <form class="form-inline mb-3">
            <input type="text"
                style="width: 150px;"
                id="p_name_input" name="product_name"
                class="form-control mr-2"
                placeholder="Product name"
                required>

            <button type="button" id="showBtn" class="btn btn-info"> Show </button>
        </form>



        <!-- PRODUCTS TABLE -->
        <table class="table table-bordered bg-white">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th width="220">Actions</th>
                </tr>
            </thead>
            <tbody>

                <?php if ($products && mysqli_num_rows($products) > 0): ?>
                    <?php while ($p = mysqli_fetch_assoc($products)): ?>
                        <tr>
                            <td><?php echo $p["id"]; ?></td>
                            <td><?php echo htmlspecialchars($p["product_name"]); ?></td>
                            <td><?php echo number_format($p["price"], 2); ?></td>
                            <td>

                                <!-- UPDATE -->
                                <form method="post" action="product_action.php"
                                    class="form-inline d-inline">
                                    <input type="hidden" name="action" value="update_product">
                                    <input type="hidden" name="product_id"
                                        value="<?php echo $p["id"]; ?>">

                                    <input type="text"
                                        name="product_name"
                                        value="<?php echo htmlspecialchars($p["product_name"]); ?>"
                                        class="form-control form-control-sm mr-1"
                                        required>

                                    <input type="number"
                                        step="0.01"
                                        name="price"
                                        value="<?php echo $p["price"]; ?>"
                                        class="form-control form-control-sm mr-1"
                                        required>

                                    <button type="submit"
                                        class="btn btn-sm btn-warning">Edit</button>
                                </form>

                                <!-- DELETE -->
                                <a href="product_action.php?action=delete_product&product_id=<?php echo $p["id"]; ?>"
                                    class="btn btn-sm btn-danger"
                                    onclick="return confirm('Delete product?')">
                                    Delete
                                </a>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">No products found</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>

        <!-- PAGINATION -->
        <nav>
            <ul class="pagination">

                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="product.php?page=<?php echo $page - 1; ?>">
                            Previous
                        </a>
                    </li>
                <?php endif; ?>

                <li class="page-item disabled">
                    <span class="page-link">
                        Page <?php echo $page; ?> / <?php echo $totalPages; ?>
                    </span>
                </li>

                <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link"
                            href="product.php?page=<?php echo $page + 1; ?>">
                            Next
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </nav>

    </div>

    <script>
        document.getElementById('showBtn').addEventListener('click', function() {
            var nameInput = document.getElementById('p_name_input').value;

            if (nameInput.trim() === "") {
                alert("Please, write product name!");
                return;
            }

            // product_action.php içindeki get_info bloğuna istek atar
            fetch('product_action.php?action=get_info&p_name=' + encodeURIComponent(nameInput))
                .then(response => response.text())
                .then(data => {
                    alert(data); // PHP'den gelen cevabı alert olarak basar
                })
                .catch(error => {
                    console.error('Hata:', error);
                    alert("Sorgulama başarısız.");
                });
        });
    </script>

</body>

</html>