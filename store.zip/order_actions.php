<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";

$userId = $_SESSION["user_id"];

/* CREATE ORDER */
if (isset($_POST["action"]) && $_POST["action"] === "create_order") {

    $stmt = mysqli_prepare(
        $link,
        "INSERT INTO orders (order_date, created_by) VALUES (NOW(), ?)"
    );
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);

    header("Location: order.php");
    exit();
}

/* ADD ITEM (PRODUCT ID BASED) */
if (isset($_POST["action"]) && $_POST["action"] === "add_item") {
    $orderId     = (int) $_POST["order_id"];
    $productName = trim($_POST["product_name"]); // get prodduct name
    $price = (float) $_POST["price"];
    $qty         = (int) $_POST["quantity"];

    // firstly, find product by Id
    $checkProduct = mysqli_prepare(
        $link,
        "SELECT id, price FROM products WHERE product_name = ?"
    );
    mysqli_stmt_bind_param($checkProduct, "s", $productName);
    mysqli_stmt_execute($checkProduct);
    $result = mysqli_stmt_get_result($checkProduct);
    $pData = mysqli_fetch_assoc($result);
    if ($pData) {
        $productId = $pData['id'];


        if ($orderId > 0 && $productId > 0 && $qty > 0) {
            $stmt = mysqli_prepare(
                $link,
                "INSERT INTO items (order_id, product_id, price, quantity)
     VALUES (?, ?, ?, ?)"
            );
            mysqli_stmt_bind_param(
                $stmt,
                "iidi",
                $orderId,
                $productId,
                $pData["price"],
                $qty
            );
            mysqli_stmt_execute($stmt);
        }
    }

    header("Location: order.php?order_id=" . $orderId);
    exit();
}

/* UPDATE ITEM QUANTITY */
if (isset($_POST["action"]) && $_POST["action"] === "update_item") {

    $itemId  = (int) $_POST["item_id"];
    $orderId = (int) $_POST["order_id"];
    $qty     = (int) $_POST["quantity"];
    $price = (float) $_POST["price"];

    if ($itemId > 0 && $qty > 0) {
        $stmt = mysqli_prepare(
            $link,
            "UPDATE items SET quantity = ?, price = ? WHERE id = ?"
        );
        mysqli_stmt_bind_param($stmt, "idi", $qty, $price, $itemId);
        mysqli_stmt_execute($stmt);
    }

    header("Location: order.php?order_id=" . $orderId);
    exit();
}

/* DELETE ITEM */
if (isset($_GET["action"]) && $_GET["action"] === "delete_item") {

    $itemId  = (int) $_GET["item_id"];
    $orderId = (int) $_GET["order_id"];

    if ($itemId > 0) {
        $stmt = mysqli_prepare(
            $link,
            "DELETE FROM items WHERE id = ?"
        );
        mysqli_stmt_bind_param($stmt, "i", $itemId);
        mysqli_stmt_execute($stmt);
    }

    header("Location: order.php?order_id=" . $orderId);
    exit();
}

/* DELETE ORDER (ONLY OWNER) */
if (isset($_GET["action"]) && $_GET["action"] === "delete_order") {

    $orderId = (int) $_GET["order_id"];

    if ($orderId > 0) {
        /* delete items first */
        $stmtItems = mysqli_prepare(
            $link,
            "DELETE FROM items WHERE order_id = ?"
        );
        mysqli_stmt_bind_param($stmtItems, "i", $orderId);
        mysqli_stmt_execute($stmtItems);

        /* delete order */
        $stmtOrder = mysqli_prepare(
            $link,
            "DELETE FROM orders WHERE id = ? AND created_by = ?"
        );
        mysqli_stmt_bind_param($stmtOrder, "ii", $orderId, $userId);
        mysqli_stmt_execute($stmtOrder);
    }

    header("Location: order.php");
    exit();
}

/* ORDER INFO SEARCH (ID İLE) */
if (isset($_GET['action']) && $_GET['action'] === 'get_order_info') {
    ob_clean(); // HTML sızıntısını önler
    
    $orderId = (int)$_GET['order_id']; 
    
    // 1. Önce Sipariş ve Kullanıcı bilgisini alalım
    $sqlOrder = "SELECT orders.id, orders.order_date, users.username 
                 FROM orders 
                 JOIN users ON orders.created_by = users.id 
                 WHERE orders.id = $orderId LIMIT 1";
    $resOrder = mysqli_query($link, $sqlOrder);

    if ($order = mysqli_fetch_assoc($resOrder)) {
        $output = "SİPARİŞ NO: #" . $order['id'] . "\n";
        $output .= "Date: " . $order['order_date'] . "\n";
        $output .= "SELLER: " . $order['username'] . "\n";
        $output .= "----------------------------------\n";
        $output .= "PRODUCTS:\n";

        // 2. Şimdi bu siparişe ait kalemleri (items) alalım
        $sqlItems = "SELECT items.quantity, items.price, products.product_name 
                     FROM items 
                     JOIN products ON items.product_id = products.id 
                     WHERE items.order_id = $orderId";
        $resItems = mysqli_query($link, $sqlItems);

        $grandTotal = 0;
        if (mysqli_num_rows($resItems) > 0) {
            while ($item = mysqli_fetch_assoc($resItems)) {
                $subTotal = $item['quantity'] * $item['price'];
                $grandTotal += $subTotal;
                $output .= "- " . $item['product_name'] . " x " . $item['quantity'] . " | " . number_format($item['price'], 2) . " TL\n";
            }
        } else {
            $output .= "No product for this Order.\n";
        }

        $output .= "----------------------------------\n";
        $output .= "TOTAL PRICE: " . number_format($grandTotal, 2) . " TL";
        
        echo $output;
    } else {
        echo "error: #" . $orderId . " doesnt find!";
    }
    
    exit(); 
}


/* FALLBACK */
header("Location: order.php");
exit();
