<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";

$userId   = $_SESSION["user_id"];
$username = $_SESSION["username"];

/* =======================
   PAGINATION
   ======================= */
$limit = 10;
$page  = isset($_GET["page"]) ? (int)$_GET["page"] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

/* TOTAL ORDERS (ONLY USER) */
$stmtCount = mysqli_prepare(
    $link,
    "SELECT COUNT(*) FROM orders WHERE created_by = ?"
);
mysqli_stmt_bind_param($stmtCount, "i", $userId);
mysqli_stmt_execute($stmtCount);
mysqli_stmt_bind_result($stmtCount, $totalOrders);
mysqli_stmt_fetch($stmtCount);
mysqli_stmt_close($stmtCount);

$totalPages = ceil($totalOrders / $limit);

/* ORDERS LIST */
$stmtOrders = mysqli_prepare(
    $link,
    "SELECT orders.id, orders.order_date, users.username
     FROM orders
     JOIN users ON orders.created_by = users.id
     WHERE orders.created_by = ?
     ORDER BY orders.id DESC
     LIMIT ? OFFSET ?"
);
mysqli_stmt_bind_param($stmtOrders, "iii", $userId, $limit, $offset);
mysqli_stmt_execute($stmtOrders);
$orders = mysqli_stmt_get_result($stmtOrders);

/* SELECTED ORDER */
$orderId = null;
$selectedOrder = null;
$orderItems = null;

if (isset($_GET["order_id"]) && is_numeric($_GET["order_id"])) {
    $orderId = (int)$_GET["order_id"];

    /* ORDER HEADER */
    $stmtOrder = mysqli_prepare(
        $link,
        "SELECT orders.id, orders.order_date, users.username
         FROM orders
         JOIN users ON orders.created_by = users.id
         WHERE orders.id = ? AND orders.created_by = ?"
    );
    mysqli_stmt_bind_param($stmtOrder, "ii", $orderId, $userId);
    mysqli_stmt_execute($stmtOrder);
    $selectedOrder = mysqli_stmt_get_result($stmtOrder);

    /* ORDER ITEMS */
    $stmtItems = mysqli_prepare(
        $link,
        "SELECT items.id, items.quantity,  items.price, products.product_name
         FROM items
         JOIN products ON items.product_id = products.id
         WHERE items.order_id = ?"
    );
    mysqli_stmt_bind_param($stmtItems, "i", $orderId);
    mysqli_stmt_execute($stmtItems);
    $orderItems = mysqli_stmt_get_result($stmtItems);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Orders</title>
    <link rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body class="bg-light">

    <!-- NAVBAR / DASHBOARD MENU -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <span class="navbar-brand">
            Welcome, <?= htmlspecialchars($username) ?>
        </span>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="product.php">Products</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="order.php">Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">

        <div class="d-flex justify-content-between mb-3">
            <h3>Orders</h3>
        </div>

        <!-- CREATE ORDER -->
        <form method="post" action="order_actions.php" class="mb-3">
            <input type="hidden" name="action" value="create_order">
            <button type="submit" class="btn btn-success">+ Create Order</button>
        </form>

        <div class="form-inline mb-3">
            <input type="number"
                id="order_id_search"
                class="form-control mr-2"
                style="width: 150px;"
                placeholder="Order ID"
                required>

            <button type="button" id="showOrderBtn" class="btn btn-primary">Show Order Information</button>
        </div>

        <!-- ORDERS TABLE -->
        <table class="table table-bordered bg-white">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Created By</th>
                    <th width="180">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($o = mysqli_fetch_assoc($orders)): ?>
                    <tr>
                        <td><?= $o["id"] ?></td>
                        <td><?= $o["order_date"] ?></td>
                        <td><?= htmlspecialchars($o["username"]) ?></td>
                        <td>
                            <a href="order.php?page=<?= $page ?>&order_id=<?= $o["id"] ?>"
                                class="btn btn-sm btn-primary">View</a>
                            <a href="order_actions.php?action=delete_order&order_id=<?= $o["id"] ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete order?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- PAGINATION -->
        <nav>
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="order.php?page=<?= $page - 1 ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="order.php?page=<?= $page + 1 ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <?php if ($selectedOrder && mysqli_num_rows($selectedOrder) === 1): ?>
            <?php $order = mysqli_fetch_assoc($selectedOrder); ?>

            <hr>
            <h4>
                Order #<?= $order["id"] ?>
                <small class="text-muted">(<?= htmlspecialchars($order["username"]) ?>)</small>
            </h4>

            <!-- ORDER ITEMS -->
            <table class="table table-striped bg-white">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th width="220">Quantity</th>
                        <th width="120">Price</th>
                        <th width="150">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = mysqli_fetch_assoc($orderItems)): ?>
                        <tr>
                            <!-- PRODUCT -->
                            <td><?= htmlspecialchars($item["product_name"]) ?></td>

                            <!-- QUANTITY -->
                            <td>
                                <form method="post" action="order_actions.php" class="form-inline">
                                    <input type="hidden" name="action" value="update_item">
                                    <input type="hidden" name="item_id" value="<?= $item["id"] ?>">
                                    <input type="hidden" name="order_id" value="<?= $order["id"] ?>">

                                    <input type="number" name="quantity"
                                        value="<?= $item["quantity"] ?>"
                                        class="form-control form-control-sm"
                                        min="1" required>
                            </td>

                            <!-- PRICE -->
                            <td>
                                <input type="number" step="0.01" name="price"
                                    value="<?= $item["price"] ?>"
                                    class="form-control form-control-sm"
                                    required>
                            </td>

                            <!-- ACTION -->
                            <td>
                                <button type="submit" class="btn btn-sm btn-warning mr-1">
                                    Edit
                                </button>
                                </form>

                                <a href="order_actions.php?action=delete_item&item_id=<?= $item["id"] ?>&order_id=<?= $order["id"] ?>"
                                    class="btn btn-sm btn-danger">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>

            </table>

            <!-- ADD ITEM -->
            <form method="post" action="order_actions.php" class="form-inline mt-3">
                <input type="hidden" name="action" value="add_item">
                <input type="hidden" name="order_id" value="<?= $order["id"] ?>">
                <input type="text" name="product_name"
                    class="form-control mr-2"
                    placeholder="Product name" required>
                <input type="number" name="quantity"
                    class="form-control mr-2"
                    min="1" placeholder="Qty" required>
                <button type="submit" class="btn btn-primary">Add Item</button>
            </form>

        <?php endif; ?>

    </div>

    <script>
        document.getElementById('showOrderBtn').addEventListener('click', function() {
            var orderId = document.getElementById('order_id_search').value;

            if (orderId.trim() === "") {
                alert("Please, write order id!");
                return;
            }

            // Burayı order_actions.php olarak güncelledik:
            fetch('order_actions.php?action=get_order_info&order_id=' + orderId)
                .then(response => response.text())
                .then(data => {
                    alert(data.trim());
                })
                .catch(error => {
                    console.error('Hata:', error);
                    alert("Bilgi getirilirken bir hata oluştu.");
                });
        });
    </script>

</body>

</html>