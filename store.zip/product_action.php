<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";


/* ADD PRODUCT */
if (isset($_POST["action"]) && $_POST["action"] === "add_product") {
    $name = trim($_POST["product_name"]);
    $price = (float)$_POST["price"];

    // 1. Önce bu ürün adı zaten var mı diye kontrol edelim
    $check_sql = "SELECT id FROM products WHERE product_name = '$name'";
    $check_res = mysqli_query($link, $check_sql);

    if (mysqli_num_rows($check_res) > 0) {
        // Ürün zaten varsa hata mesajıyla geri dön
        header("Location: product.php?error=already_exists");
        exit();
    } else {
        // 2. Ürün yoksa ekleme işlemini yap
        $stmt = mysqli_prepare($link, "INSERT INTO products (product_name, price) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "sd", $name, $price);
        
        if (mysqli_stmt_execute($stmt)) {
            header("Location: product.php?success=added");
        } else {
            echo "Hata oluştu: " . mysqli_error($link);
        }
    }
    exit();
}

/* UPDATE PRODUCT */
if (isset($_POST["action"]) && $_POST["action"] === "update_product") {

    $id    = (int) $_POST["product_id"];
    $name  = trim($_POST["product_name"]);
    $price = (float) $_POST["price"];

    if ($id > 0 && $name !== "" && $price > 0) {
        $stmt = mysqli_prepare(
            $link,
            "UPDATE products SET product_name = ?, price = ? WHERE id = ?"
        );
        mysqli_stmt_bind_param($stmt, "sdi", $name, $price, $id);
        mysqli_stmt_execute($stmt);
    }

    header("Location: product.php");
    exit();
}

/* DELETE PRODUCT */
if (isset($_GET["action"]) && $_GET["action"] === "delete_product") {

    $id = (int) $_GET["product_id"];

    if ($id > 0) {
        $stmt = mysqli_prepare($link, "DELETE FROM products WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
    }

    header("Location: product.php");
    exit();
}

/* GET PRODUCT INFO (ALERT İÇİN) */
if (isset($_GET['action']) && $_GET['action'] === 'get_info') {
    // Önceki tüm çıktıları temizle (HTML kodlarını engeller)
    ob_clean(); 
    
    require_once "config.php";
    $name = mysqli_real_escape_string($link, $_GET['p_name']);
    
    $sql = "SELECT * FROM products WHERE product_name = '$name' LIMIT 1";
    $result = mysqli_query($link, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        echo "ID: " . $row['id'] . "\n" .
             "ProductName: " . $row['product_name'] . "\n" . 
             "Price: " . $row['price'] . " TL";
    } else {
        echo "Product wasnot find!";
    }
    
    // Arkasından gelebilecek her şeyi durdur
    exit(); 
}


/* FALLBACK */
header("Location: product.php");
exit();
