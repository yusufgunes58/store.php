<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";

/* SIMPLE COUNTS */
$productCount = mysqli_num_rows(mysqli_query($link, "SELECT id FROM products"));
$orderCount   = mysqli_num_rows(mysqli_query($link, "SELECT id FROM orders"));

$username = $_SESSION["username"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Store </title>

    <link rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        .banner {
            background-color: #343a40;
            color: white;
            padding: 25px;
            text-align: center;
            margin-bottom: 30px;
        }

        .banner h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .banner p {
            font-size: 14px;
            margin: 0;
            color: #ccc;
        }

        .dashboard-card {
            cursor: pointer;
            transition: 0.3s;
        }

        .dashboard-card:hover {
            transform: scale(1.03);
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
    </style>

    
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <span class="navbar-brand">
        Welcome, <?php echo $username; ?>
    </span>

    <div class="collapse navbar-collapse">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="product.php">Products</a></li>
            <li class="nav-item"><a class="nav-link" href="order.php">Orders</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- BANNER -->
<div class="banner">
    <h1>oO      My Store    oO</h1>
</div>

<!-- MAIN CONTENT -->
<div class="container">

    <!-- DASHBOARD CARDS -->
    <div class="row text-center">

        <div class="col-md-4 mb-3">
            <a href="product.php" class="text-dark" style="text-decoration:none;">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <h5 class="card-title">Products</h5>
                        <p class="card-text">Manage product information</p>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="order.php" class="text-dark" style="text-decoration:none;">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <h5 class="card-title">Orders</h5>
                        <p class="card-text">View and manage orders</p>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-md-4 mb-3">
            <a href="order.php" class="text-dark" style="text-decoration:none;">
                <div class="card dashboard-card">
                    <div class="card-body">
                        <h5 class="card-title">New Order</h5>
                        <p class="card-text">Create a new order</p>
                    </div>
                </div>
            </a>
        </div>

    </div>

    <hr>

    <!-- SLIDER / STATISTICS -->
    <div id="statsSlider" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">

            <div class="carousel-item active text-center p-4 bg-light">
                <h5>Total Products</h5>
                <h2><?php echo $productCount; ?></h2>
            </div>

            <div class="carousel-item text-center p-4 bg-light">
                <h5>Total Orders</h5>
                <h2><?php echo $orderCount; ?></h2>
            </div>

        </div>

        <a class="carousel-control-prev" href="#statsSlider" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#statsSlider" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>

</div>

</body>
</html>
