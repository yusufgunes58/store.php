<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Insert Record Page </title>
</head>
<body>
<?php    

$conn = mysqli_connect("localhost", "root", "", "store");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// admin 
$sql = "INSERT INTO users (username, password)
        VALUES ('mertkartepe', '1234')";
mysqli_query($conn, $sql);

$sql = "INSERT INTO users (username, password)
        VALUES ('yusufgunes', '123')";
mysqli_query($conn, $sql);

// products
$sql = "INSERT INTO products (product_name, price)
        VALUES ('Body101', 65)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO products (product_name, price)
        VALUES ('Body223', 70)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO products (product_name, price)
        VALUES ('Pant059', 250)";
mysqli_query($conn, $sql);


// order
$sql = "INSERT INTO orders (order_date, created_by)
        VALUES ('2025-01-18 14:30:00', 1)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO orders (order_date, created_by)
        VALUES ('2025-01-15 14:30:00', 1)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO orders (order_date, created_by)
        VALUES ('2025-01-13 14:30:00', 1)";
mysqli_query($conn, $sql);

// order items
$sql = "INSERT INTO items (order_id, product_id, quantity)
        VALUES (1, 1, 10)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO items (order_id, product_id, quantity)
        VALUES (1, 2, 20)";
mysqli_query($conn, $sql);

$sql = "INSERT INTO items (order_id, product_id, quantity)
        VALUES (2, 2, 50)";
mysqli_query($conn, $sql);

?>
</body>
</html>