<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Create Tables Page</title>
</head>

<body>

    <?php

    $conn = mysqli_connect("localhost", "root", "", "store");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $users_table = "
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";

   if (mysqli_query($conn, $users_table)) {
        echo "Table created successfully.";
    } else {
        echo "ERROR: Could not able to execute $users_table. " . mysqli_error($conn);
    }

    $products_table = "
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL UNIQUE,
    price DECIMAL(10,2) NOT NULL
)";

    if (mysqli_query($conn, $products_table)) {
        echo "Table created successfully.";
    } else {
        echo "ERROR: Could not able to execute $products_table. " . mysqli_error($conn);
    }


    $orders_table = "
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_date DATETIME NOT NULL,
    created_by INT NOT NULL,
    FOREIGN KEY (created_by)  REFERENCES users(id)
)";

    if (mysqli_query($conn, $orders_table)) {
        echo "Table created successfully.";
    } else {
        echo "ERROR: Could not able to execute $orders_table. " . mysqli_error($conn);
    }

    $items_table = "
CREATE TABLE items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
)";

    if (mysqli_query($conn, $items_table)) {
        echo "Table created successfully.";
    } else {
        echo "ERROR: Could not able to execute $items_table. " . mysqli_error($conn);
    }


    $conn->close();
    ?>

</body>

</html>